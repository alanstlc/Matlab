%-------------------------------------------------------------------------
%Program pro vypo�ten� pr�m�rn� elevace a azimutu
%Alan �tolc, �VUT FEl, 2013
%-------------------------------------------------------------------------

clc;
clear all;
close all;

%Pro vykreslen� dan�ho typu m��en� je nutn� je odkomentovat, u m��en� pomoc�
%joysticku je takt� nutn� odkomentovat vykreslen� azimutu 40�
 matrix=load('all_mys_ucebni.txt');
% matrix=load('all_mys.txt');
% matrix=load('all_jst.txt');
% matrix=load('all_jst_blind.txt');
% matrix=load('all_boltec.txt');

%zji�t�n� d�lky matice
delka=length(matrix);

%vyhled�v�n� konkr�tn�ch hodnot azimut� a elevac�
elev0=find(matrix(:,3)==0);
elev6=find(matrix(:,3)==6.4286);
elev12=find(matrix(:,3)==12.8570);
elev19=find(matrix(:,3)==19.286);
elev25=find(matrix(:,3)==25.714);
elev32=find(matrix(:,3)==32.143);
elev38=find(matrix(:,3)==38.571);
elev45=find(matrix(:,3)==45);
elevm6=find(matrix(:,3)==-6.4286);
elevm12=find(matrix(:,3)==-12.8570);
elevm19=find(matrix(:,3)==-19.286);
elevm25=find(matrix(:,3)==-25.714);
elevm32=find(matrix(:,3)==-32.143);
elevm38=find(matrix(:,3)==-38.571);
elevm45=find(matrix(:,3)==-45);

azim0=find(matrix(:,2)==0);
azim5=find(matrix(:,2)==5);
azim10=find(matrix(:,2)==10);
azim15=find(matrix(:,2)==15);
azim20=find(matrix(:,2)==20);
azim25=find(matrix(:,2)==25);
azim30=find(matrix(:,2)==30);
azim35=find(matrix(:,2)==35);
azim40=find(matrix(:,2)==40);
azim45=find(matrix(:,2)==45);
azimm5=find(matrix(:,2)==-5);
azimm10=find(matrix(:,2)==-10);
azimm15=find(matrix(:,2)==-15);
azimm20=find(matrix(:,2)==-20);
azimm25=find(matrix(:,2)==-25);
azimm30=find(matrix(:,2)==-30);
azimm35=find(matrix(:,2)==-35);
azimm40=find(matrix(:,2)==-40);
azimm45=find(matrix(:,2)==-45);

%vytvo�en� pr�m�rn�ch odchylek
for i=1:delka
matrix(i,6)=abs(matrix(i,2)-matrix(i,4));
matrix(i,7)=abs(matrix(i,3)-matrix(i,5));
end;

%vypo�ten� pr�m�rn�ch odchylek
elev0_avg=mean(matrix(elev0,7));
elev6_avg=mean(matrix(elev6,7));
elev12_avg=mean(matrix(elev12,7));
elev19_avg=mean(matrix(elev19,7));
elev25_avg=mean(matrix(elev25,7));
elev32_avg=mean(matrix(elev32,7));
elev38_avg=mean(matrix(elev38,7));
elev45_avg=mean(matrix(elev45,7));
elevm6_avg=mean(matrix(elevm6,7));
elevm12_avg=mean(matrix(elevm12,7));
elevm19_avg=mean(matrix(elevm19,7));
elevm25_avg=mean(matrix(elevm25,7));
elevm32_avg=mean(matrix(elevm32,7));
elevm38_avg=mean(matrix(elevm38,7));
elevm45_avg=mean(matrix(elevm45,7));

elev0_min=min(matrix(elev0,7));
elev6_min=min(matrix(elev6,7));
elev12_min=min(matrix(elev12,7));
elev19_min=min(matrix(elev19,7));
elev25_min=min(matrix(elev25,7));
elev32_min=min(matrix(elev32,7));
elev38_min=min(matrix(elev38,7));
elev45_min=min(matrix(elev45,7));
elevm6_min=min(matrix(elevm6,7));
elevm12_min=min(matrix(elevm12,7));
elevm19_min=min(matrix(elevm19,7));
elevm25_min=min(matrix(elevm25,7));
elevm32_min=min(matrix(elevm32,7));
elevm38_min=min(matrix(elevm38,7));
elevm45_min=min(matrix(elevm45,7));

elev0_max=max(matrix(elev0,7));
elev6_max=max(matrix(elev6,7));
elev12_max=max(matrix(elev12,7));
elev19_max=max(matrix(elev19,7));
elev25_max=max(matrix(elev25,7));
elev32_max=max(matrix(elev32,7));
elev38_max=max(matrix(elev38,7));
elev45_max=max(matrix(elev45,7));
elevm6_max=max(matrix(elevm6,7));
elevm12_max=max(matrix(elevm12,7));
elevm19_max=max(matrix(elevm19,7));
elevm25_max=max(matrix(elevm25,7));
elevm32_max=max(matrix(elevm32,7));
elevm38_max=max(matrix(elevm38,7));
elevm45_max=max(matrix(elevm45,7));


azim0_avg=mean(matrix(azim0,6));
azim5_avg=mean(matrix(azim5,6));
azim10_avg=mean(matrix(azim10,6));
azim15_avg=mean(matrix(azim15,6));
azim20_avg=mean(matrix(azim20,6));
azim25_avg=mean(matrix(azim25,6));
azim30_avg=mean(matrix(azim30,6));
azim35_avg=mean(matrix(azim35,6));
azim40_avg=mean(matrix(azim40,6));
azim45_avg=mean(matrix(azim45,6));
azimm5_avg=mean(matrix(azimm5,6));
azimm10_avg=mean(matrix(azimm10,6));
azimm15_avg=mean(matrix(azimm15,6));
azimm20_avg=mean(matrix(azimm20,6));
azimm25_avg=mean(matrix(azimm25,6));
azimm30_avg=mean(matrix(azimm30,6));
azimm35_avg=mean(matrix(azimm35,6));
azimm40_avg=mean(matrix(azimm40,6));
azimm45_avg=mean(matrix(azimm45,6));

azim0_min=min(matrix(azim0,6));
azim5_min=min(matrix(azim5,6));
azim10_min=min(matrix(azim10,6));
azim15_min=min(matrix(azim15,6));
azim20_min=min(matrix(azim20,6));
azim25_min=min(matrix(azim25,6));
azim30_min=min(matrix(azim30,6));
azim35_min=min(matrix(azim35,6));
azim40_min=min(matrix(azim40,6));
azim45_min=min(matrix(azim45,6));
azimm5_min=min(matrix(azimm5,6));
azimm10_min=min(matrix(azimm10,6));
azimm15_min=min(matrix(azimm15,6));
azimm20_min=min(matrix(azimm20,6));
azimm25_min=min(matrix(azimm25,6));
azimm30_min=min(matrix(azimm30,6));
azimm35_min=min(matrix(azimm35,6));
azimm40_min=min(matrix(azimm40,6));
azimm45_min=min(matrix(azimm45,6));

azim0_max=max(matrix(azim0,6));
azim5_max=max(matrix(azim5,6));
azim10_max=max(matrix(azim10,6));
azim15_max=max(matrix(azim15,6));
azim20_max=max(matrix(azim20,6));
azim25_max=max(matrix(azim25,6));
azim30_max=max(matrix(azim30,6));
azim35_max=max(matrix(azim35,6));
azim40_max=max(matrix(azim40,6));
azim45_max=max(matrix(azim45,6));
azimm5_max=max(matrix(azimm5,6));
azimm10_max=max(matrix(azimm10,6));
azimm15_max=max(matrix(azimm15,6));
azimm20_max=max(matrix(azimm20,6));
azimm25_max=max(matrix(azimm25,6));
azimm30_max=max(matrix(azimm30,6));
azimm35_max=max(matrix(azimm35,6));
azimm40_max=max(matrix(azimm40,6));
azimm45_max=max(matrix(azimm45,6));

%vypo�ten� pr�m�r�
elev_avg=mean(matrix(:,7))
elev_min=min(matrix(:,7));
elev_max=max(matrix(:,7));

azim_avg=mean(matrix(:,6))
azim_min=min(matrix(:,6));
azim_max=max(matrix(:,6));

%vypo�ten� pr�m�rn�ch maxim
azim_avg_max=mean([azim0_max azim5_max azim10_max azim15_max azim20_max azim25_max azim30_max azim35_max azim40_max azim45_max azimm5_max azimm10_max azimm15_max azimm20_max azimm25_max azimm30_max azimm35_max azimm40_max azimm45_max])
elev_avg_max=mean([elev0_max elev6_max elev12_max elev19_max elev25_max elev32_max elev38_max elev45_max elevm6_max elevm12_max elevm19_max elevm25_max elevm32_max elevm38_max elevm45_max])

%vypo�ten� pr�m�rn�ch minim
azim_avg_min=mean([azim0_min azim5_min azim10_min azim15_min azim20_min azim25_min azim30_min azim35_min azim40_min azim45_min azimm5_min azimm10_min azimm15_min azimm20_min azimm25_min azimm30_min azimm35_min azimm40_min azimm45_min])
elev_avg_min=mean([elev0_min elev6_min elev12_min elev19_min elev25_min elev32_min elev38_min elev45_min elevm6_min elevm12_min elevm19_min elevm25_min elevm32_min elevm38_min elevm45_min])

%vykreslen� azimutu
errorbar(0,azim0_avg,azim0_min-azim0_avg,azim0_max-azim0_avg,'+');hold on;
errorbar(5,azim5_avg,azim5_min-azim5_avg,azim5_max-azim5_avg,'+');hold on;
errorbar(10,azim10_avg,azim10_min-azim10_avg,azim10_max-azim10_avg,'+');hold on;
errorbar(15,azim15_avg,azim15_min-azim15_avg,azim15_max-azim15_avg,'+');hold on;
errorbar(20,azim20_avg,azim20_min-azim20_avg,azim20_max-azim20_avg,'+');hold on;
errorbar(25,azim25_avg,azim25_min-azim25_avg,azim25_max-azim25_avg,'+');hold on;
errorbar(30,azim30_avg,azim30_min-azim30_avg,azim30_max-azim30_avg,'+');hold on;
errorbar(35,azim35_avg,azim35_min-azim35_avg,azim35_max-azim35_avg,'+');hold on;
errorbar(40,azim40_avg,azim40_min-azim40_avg,azim40_max-azim40_avg,'+');hold on;
%errorbar(45,azim45_avg,azim45_min-azim45_avg,azim45_max-azim45_avg,'+');
errorbar(-5,azimm5_avg,azimm5_min-azimm5_avg,azimm5_max-azimm5_avg,'+');hold on;
errorbar(-10,azimm10_avg,azimm10_min-azimm10_avg,azimm10_max-azimm10_avg,'+');hold on;
errorbar(-15,azimm15_avg,azimm15_min-azimm15_avg,azimm15_max-azimm15_avg,'+');hold on;
errorbar(-20,azimm20_avg,azimm20_min-azimm20_avg,azimm20_max-azimm20_avg,'+');hold on;
errorbar(-25,azimm25_avg,azimm25_min-azimm25_avg,azimm25_max-azimm25_avg,'+');hold on;
errorbar(-30,azimm30_avg,azimm30_min-azimm30_avg,azimm30_max-azimm30_avg,'+');hold on;
errorbar(-35,azimm35_avg,azimm35_min-azimm35_avg,azimm35_max-azimm35_avg,'+');hold on;
errorbar(-40,azimm40_avg,azimm40_min-azimm40_avg,azimm40_max-azimm40_avg,'+');
%errorbar(-45,azimm45_avg,azimm45_min-azimm45_avg,azimm45_max-azimm45_avg,'+');
ylim([0 azim_max+5]);xlim([-50 50]);
ylabel('Chyba odhadu');xlabel('Azimut (�)');
title('Nam��en� hodnoty')


%vykreslen� elevace
figure(2);
errorbar(0,elev0_avg,elev0_min-elev0_avg,elev0_max-elev0_avg,'+');hold on;
errorbar(6,elev6_avg,elev6_min-elev6_avg,elev6_max-elev6_avg,'+');hold on;
errorbar(12,elev12_avg,elev12_min-elev12_avg,elev12_max-elev12_avg,'+');hold on;
errorbar(19,elev19_avg,elev19_min-elev19_avg,elev19_max-elev19_avg,'+');hold on;
errorbar(25,elev25_avg,elev25_min-elev25_avg,elev25_max-elev25_avg,'+');hold on;
errorbar(32,elev32_avg,elev32_min-elev32_avg,elev32_max-elev32_avg,'+');hold on;
errorbar(38,elev38_avg,elev38_min-elev38_avg,elev38_max-elev38_avg,'+');hold on;
%errorbar(45,elev45_avg,elev45_min-elev45_avg,elev45_max-elev45_avg,'+');hold on;
errorbar(-6,elevm6_avg,elevm6_min-elevm6_avg,elevm6_max-elevm6_avg,'+');hold on;
errorbar(-12,elevm12_avg,elevm12_min-elevm12_avg,elevm12_max-elevm12_avg,'+');hold on;
errorbar(-19,elevm19_avg,elevm19_min-elevm19_avg,elevm19_max-elevm19_avg,'+');hold on;
errorbar(-25,elevm25_avg,elevm25_min-elevm25_avg,elevm25_max-elevm25_avg,'+');hold on;
errorbar(-32,elevm32_avg,elevm32_min-elevm32_avg,elevm32_max-elevm32_avg,'+');hold on;
errorbar(-38,elevm38_avg,elevm38_min-elevm38_avg,elevm38_max-elevm38_avg,'+');hold on;
%errorbar(-45,elevm45_avg,elevm45_min-elevm45_avg,elevm45_max-elevm45_avg,'+');hold on;
ylim([0 elev_max+5]);xlim([-50 50]);
ylabel('Chyba odhadu');xlabel('Elevace (�)');
title('Nam��en� hodnoty');

%vypo�ten� pr�m�r� pro horn� a doln� polorovinu
elevhorni_avg=mean(matrix([elev0; elev6; elev12; elev19; elev25; elev32; elev38],7))
elevdolni_avg=mean(matrix([elev0; elevm6; elevm12; elevm19; elevm25; elevm32; elevm38],7))