%-------------------------------------------------------------------------
%Program pro vykreslen� elevace a azimutu
%Alan �tolc, �VUT FEl, 2013
%-------------------------------------------------------------------------

clc;
clear all;
close all;

%Pro vykreslen� dan�ho typu m��en� je nutn� je odkomentovat, u m��en� pomoc�
%joysticku je takt� nutn� odkomentovat vykreslen� azimutu 40�
 matrix=load('all_mys_ucebni.txt');
% matrix=load('all_mys.txt');
% matrix=load('all_jst.txt');
% matrix=load('all_jst_blind.txt');
% matrix=load('all_boltec.txt');

%zji�t�n� d�lky matice
delka=length(matrix);

%vyhled�v�n� konkr�tn�ch hodnot azimut� a elevac�
elev0=find(matrix(:,3)==0);
elev6=find(matrix(:,3)==6.4286);
elev12=find(matrix(:,3)==12.8570);
elev19=find(matrix(:,3)==19.286);
elev25=find(matrix(:,3)==25.714);
elev32=find(matrix(:,3)==32.143);
elev38=find(matrix(:,3)==38.571);
elev45=find(matrix(:,3)==45);
elevm6=find(matrix(:,3)==-6.4286);
elevm12=find(matrix(:,3)==-12.8570);
elevm19=find(matrix(:,3)==-19.286);
elevm25=find(matrix(:,3)==-25.714);
elevm32=find(matrix(:,3)==-32.143);
elevm38=find(matrix(:,3)==-38.571);
elevm45=find(matrix(:,3)==-45);

azim0=find(matrix(:,2)==0);
azim5=find(matrix(:,2)==5);
azim10=find(matrix(:,2)==10);
azim15=find(matrix(:,2)==15);
azim20=find(matrix(:,2)==20);
azim25=find(matrix(:,2)==25);
azim30=find(matrix(:,2)==30);
azim35=find(matrix(:,2)==35);
azim40=find(matrix(:,2)==40);
azim45=find(matrix(:,2)==45);
azimm5=find(matrix(:,2)==-5);
azimm10=find(matrix(:,2)==-10);
azimm15=find(matrix(:,2)==-15);
azimm20=find(matrix(:,2)==-20);
azimm25=find(matrix(:,2)==-25);
azimm30=find(matrix(:,2)==-30);
azimm35=find(matrix(:,2)==-35);
azimm40=find(matrix(:,2)==-40);
azimm45=find(matrix(:,2)==-45);

%zji�t�n� pr�m�rn�ch azimut� a elevac�
azim0_avg=mean(matrix(azim0,4));
azim5_avg=mean(matrix(azim5,4));
azim10_avg=mean(matrix(azim10,4));
azim15_avg=mean(matrix(azim15,4));
azim20_avg=mean(matrix(azim20,4));
azim25_avg=mean(matrix(azim25,4));
azim30_avg=mean(matrix(azim30,4));
azim35_avg=mean(matrix(azim35,4));
azim40_avg=mean(matrix(azim40,4));
azim45_avg=mean(matrix(azim45,4));
azimm5_avg=mean(matrix(azimm5,4));
azimm10_avg=mean(matrix(azimm10,4));
azimm15_avg=mean(matrix(azimm15,4));
azimm20_avg=mean(matrix(azimm20,4));
azimm25_avg=mean(matrix(azimm25,4));
azimm30_avg=mean(matrix(azimm30,4));
azimm35_avg=mean(matrix(azimm35,4));
azimm40_avg=mean(matrix(azimm40,4));
azimm45_avg=mean(matrix(azimm45,4));

elev0_avg=mean(matrix(elev0,5));
elev6_avg=mean(matrix(elev6,5));
elev12_avg=mean(matrix(elev12,5));
elev19_avg=mean(matrix(elev19,5));
elev25_avg=mean(matrix(elev25,5));
elev32_avg=mean(matrix(elev32,5));
elev38_avg=mean(matrix(elev38,5));
elev45_avg=mean(matrix(elev45,5));
elevm6_avg=mean(matrix(elevm6,5));
elevm12_avg=mean(matrix(elevm12,5));
elevm19_avg=mean(matrix(elevm19,5));
elevm25_avg=mean(matrix(elevm25,5));
elevm32_avg=mean(matrix(elevm32,5));
elevm38_avg=mean(matrix(elevm38,5));
elevm45_avg=mean(matrix(elevm45,5));




%vykreslen� azimut� a elevac�
figure;plot(0,matrix(elev0,5),'O','MarkerSize',12);hold on;
plot(0,0,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(0,elev0_avg,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(6.4,matrix(elev6,5),'O','MarkerSize',12);hold on;
plot(6.4,6.4,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(6.4,elev6_avg,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(12.8,matrix(elev12,5),'O','MarkerSize',12);hold on;
plot(12.8,12.8,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(12.8,elev12_avg,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(19.2,matrix(elev19,5),'O','MarkerSize',12);hold on;
plot(19.2,19.2,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(19.2,elev19_avg,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(25.7,matrix(elev25,5),'O','MarkerSize',12);hold on;
plot(25.7,25.7,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(25.7,elev25_avg,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(32.2,matrix(elev32,5),'O','MarkerSize',12);hold on;
plot(32.2,32.2,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(32.2,elev32_avg,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(38.6,matrix(elev38,5),'O','MarkerSize',12);hold on;
plot(38.6,38.6,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(38.6,elev38_avg,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(-6.4,matrix(elevm6,5),'O','MarkerSize',12);hold on;
plot(-6.4,-6.4,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(-6.4,elevm6_avg,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(-12.8,matrix(elevm12,5),'O','MarkerSize',12);hold on;
plot(-12.8,-12.8,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(-12.8,elevm12_avg,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(-19.2,matrix(elevm19,5),'O','MarkerSize',12);hold on;
plot(-19.2,-19.2,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(-19.2,elevm19_avg,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(-25.7,matrix(elevm25,5),'O','MarkerSize',12);hold on;
plot(-25.7,-25.7,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(-25.7,elevm25_avg,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(-32.2,matrix(elevm32,5),'O','MarkerSize',12);hold on;
plot(-32.2,-32.2,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(-32.2,elevm32_avg,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(-38.6,matrix(elevm38,5),'O','MarkerSize',12);hold on;
plot(-38.6,-38.6,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(-38.6,elevm38_avg,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
ylim([-45 45]);xlim([-45 45]);
ylabel('Nam��en� elevace');xlabel('Elevace (�)');
title('Nam��en� hodnoty');




figure;plot(matrix(azim0,4),0,'O','MarkerSize',12);hold on;
plot(0,0,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(azim0_avg,0,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(matrix(azim5,4),5,'O','MarkerSize',12);hold on;
plot(5,5,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(azim5_avg,5,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(matrix(azim10,4),10,'O','MarkerSize',12);hold on;
plot(10,10,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(azim10_avg,10,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(matrix(azim15,4),15,'O','MarkerSize',12);hold on;
plot(15,15,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(azim15_avg,15,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(matrix(azim20,4),20,'O','MarkerSize',12);hold on;
plot(20,20,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(azim20_avg,20,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(matrix(azim25,4),25,'O','MarkerSize',12);hold on;
plot(25,25,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(azim25_avg,25,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(matrix(azim30,4),30,'O','MarkerSize',12);hold on;
plot(30,30,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(azim30_avg,30,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(matrix(azim35,4),35,'O','MarkerSize',12);hold on;
plot(35,35,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(azim35_avg,35,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(matrix(azim40,4),40,'O','MarkerSize',12);hold on;
plot(40,40,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(azim40_avg,40,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(matrix(azimm5,4),-5,'O','MarkerSize',12);hold on;
plot(-5,-5,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(azimm5_avg,-5,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(matrix(azimm10,4),-10,'O','MarkerSize',12);hold on;
plot(-10,-10,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(azimm10_avg,-10,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(matrix(azimm15,4),-15,'O','MarkerSize',12);hold on;
plot(-15,-15,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(azimm15_avg,-15,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(matrix(azimm20,4),-20,'O','MarkerSize',12);hold on;
plot(-20,-20,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(azimm20_avg,-20,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(matrix(azimm25,4),-25,'O','MarkerSize',12);hold on;
plot(-25,-25,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(azimm25_avg,-25,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(matrix(azimm30,4),-30,'O','MarkerSize',12);hold on;
plot(-30,-30,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(azimm30_avg,-30,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(matrix(azimm35,4),-35,'O','MarkerSize',12);hold on;
plot(-35,-35,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(azimm35_avg,-35,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
plot(matrix(azimm40,4),-40,'O','MarkerSize',12);hold on;
plot(-40,-40,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','c');hold on;
plot(azimm40_avg,-40,'O','MarkerSize',6,'MarkerEdgeColor','k', 'MarkerFaceColor','b');hold on;
ylim([-45 45]);xlim([-45 45]);
ylabel('Azimut');xlabel('Nam��en� azimut (�)');
title('Nam��en� hodnoty');